#ifndef __NEWPLAN_RDMA_CHANNEL_H__
#define __NEWPLAN_RDMA_CHANNEL_H__
#include <glog/logging.h>

class RDMAAdapter;
class PreConnector;

// structure to save the address of remote channels.
struct RdmaAddress
{
    uint32_t lid;
    uint32_t qpn;
    uint32_t psn;
    uint64_t snp;
    uint64_t iid;
};

struct ChannelParams
{
    uint8_t port_num;
    uint8_t sgid_index;
    uint8_t pkey_index;
    uint32_t queue_depth;
    uint8_t timeout;
    uint8_t retry_cnt;
    uint8_t sl;
    enum ibv_mtu mtu;
    uint8_t traffic_class;
};

struct ChannelContext
{
    ibv_qp *qp_;
}

class RDMAChannel
{
public:
    explicit RDMAChannel(RDMAAdapter *rdma_adapter)
        : rdma_adapter_(rdma_adapter)
    {
        memset(&res, 0, sizeof(struct ChannelParams));
        memset(&self_, 0, sizeof(struct RDMAAddress));
        memset(&remote_, 0, sizeof(struct RDMAAddress));
        LOG(INFO) << "Creating RDMAChannel...";
    }

    ~RDMAChannel()
    {
        LOG(INFO) << "Destroying RDMAChannel...";
    }

    void connect(RdmaAddress &peer_point)
    {
        LOG(INFO) << "Connect to RDMAChannel...";
    }

    void connect()
    {
        LOG(INFO) << "Connect to RDMAChannel...";
    }

    RDMAAddress &self() { return self_; }
    RDMAAddress &peer() { return peer_; }

private:
    RDMAAdapter *rdma_adapter_ = nullptr;
    ChannelParams res_;
    RdmaAddress self_, peer_;
    PreConnector *pre_connector = nullptr;
    ChannelContext *rdma_ctx = nullptr;
};
#endif