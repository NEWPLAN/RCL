class RDMASession
    class RDMAChannel-->DataChannel
    class RDMAChannel-->ControlChannel
    class PreConnector-->tcpConnection
    class RDMAAdapter--> RDMA device

class Server:
    class RDMASession n1,n2,n3,...,n

class Client:
    launch to sever side;
    class RDMASession n1
    