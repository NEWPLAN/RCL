#include <iostream>
#include <sstream>
#include "time_event.h"
#include "time_record.h"
#include "blocking_queue.h"

void time_record_test()
{
    newplan::Timer cpu_timer;
    int count = 100;
    do
    {
        cpu_timer.Start();
        std::this_thread::sleep_for(std::chrono::milliseconds(15));
        cpu_timer.Stop();
        std::cout << "[" << count << "] CPU time cost for: " << cpu_timer.MilliSeconds() << " ms" << std::endl;
    } while (count-- > 0);
}

void time_event_test()
{
    using namespace std::chrono;
    auto start = std::chrono::steady_clock::now();

    auto duration = [start]() {
        auto now = std::chrono::steady_clock::now();
        auto msecs = std::chrono::duration_cast<std::chrono::milliseconds>(now - start).count();
        std::stringstream ss;
        ss << msecs / 1000.0;
        std::cout << "elapsed " << ss.str() << "s\t: ";
    };

    std::cout << "start" << std::endl;
    newplan::TimeEvent t(1ms);
    auto e1 = t.set_timeout(3s, [&]() { duration(); std::cout << "timeout 3s" << std::endl; });
    auto e2 = t.set_interval(100ms, [&]() { duration(); std::cout << "interval 100ms" << std::endl; });
    auto e3 = t.set_timeout(4s, [&]() { duration(); std::cout << "timeout 4s" << std::endl; });
    auto e4 = t.set_interval(2s, [&]() { duration(); std::cout << "interval 2s" << std::endl; });
    auto e5 = t.set_timeout(5s, [&]() { duration(); std::cout << "timeout that never happens" << std::endl; });
    e5->cancel(); // cancel this timeout
    std::this_thread::sleep_for(5s);
    e4->cancel(); // cancel this interval
    std::cout << "cancel interval 2" << std::endl;
    std::this_thread::sleep_for(5s);
    std::cout << "end" << std::endl;
}

void blocking_queue_test()
{
    using namespace std::chrono;
    newplan::BlockingQueue<int> *bq = new newplan::BlockingQueue<int>();
    std::thread *producer_1 = new std::thread([&]() {
        for (int index = 1; index < 100; index += 2)
        {
            bq->push(index);
            std::this_thread::sleep_for(1ms);
        }
    });
    std::thread *producer_2 = new std::thread([&]() {
        for (int index = 2; index < 100; index += 2)
        {
            bq->push(index);
            std::this_thread::sleep_for(1ms);
        }
    });
    std::thread *consumer = new std::thread([&]() { 
        while(true){
            std::cout << "from consumer: " << bq->pop() << std::endl;
            } });

    producer_1->join();
    producer_2->join();
    consumer->join();
}

int main(int argc, char **argv)
{
    time_record_test();
    time_event_test();
    blocking_queue_test();
    return 0;
}