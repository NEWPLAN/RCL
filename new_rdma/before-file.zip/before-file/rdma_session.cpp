#include "rdma_session.h"
#include <glog/logging.h>

RDMASession::RDMASession()
{
}
RDMASession::~RDMASession()
{
}

RDMASession *RDMASession::build_RDMA_session(PreConnector *pre_connector)
{
    RDMASession *rdma_sess = new RDMASession();
    if (pre_connector == nullptr)
    {
        LOG(FATAL) << "Find problem on pre-connector";
    }
    rdma_sess->set_pre_connector(pre_connector);
    rdma_sess->build_rdma_channels();

    return rdma_sess;
}

void RDMASession::build_rdma_channels()
{
    //data channel
    LOG(INFO) << "Build Data channel";
    //control channel
    LOG(INFO) << "Build control channel";
}

void RDMASession::set_pre_connector(PreConnector *pre_connector)
{
    this->pre_connector_ = pre_connector;
}