#ifndef __NEWPLAN_RDMA_SESSION_H__
#define __NEWPLAN_RDMA_SESSION_H__

#include <glog/logging.h>
#include <vector>

class RDMAChannel;
class RDMAAdapter;
class PreConnector;

class RDMASession
{
public:
    RDMASession();
    ~RDMASession();

    static RDMASession *build_RDMA_session(PreConnector *pre_connector);

private:
    void set_pre_connector(PreConnector *pre_connector);

    void build_rdma_channels();

private:
    std::vector<RDMAChannel *> channel_group; //0 is the control channel, others are data channel;

    PreConnector *pre_connector_ = nullptr;
};

#endif