#include "rdma_server.h"
#include "rdma_client.h"
#include "pre_connector.h"
#include <thread>
#include <iostream>
#include <chrono>
#include <future>

void callback_server(void *args)
{
    PreConnector *pre_connector = (PreConnector *)args;
    LOG(INFO) << "Exchange data here";
    std::thread *loop_thread = new std::thread([=]() {
        do
        {
            char local_data[1024] = "server";
            char remote_data[1024] = {0};
            int recv = 0;

            recv = pre_connector->sock_sync_data(local_data, remote_data, 6);

            if (recv < 0)
            {
                LOG(INFO) << "Connection was reset by " << pre_connector->get_peer_addr();
                break;
            }

            LOG(INFO) << "Recved data from " << pre_connector->get_peer_addr() << ", recv: " << recv;

        } while (true);
        //LOG(INFO) << "cannot be here";
    });
    //loop_thread->detach();
    //std::async([=]() { loop_thread->detach(); });
}

void callback_client(void *args)
{
    PreConnector *pre_connector = (PreConnector *)args;
    LOG(INFO) << "Exchange data here";
    std::thread *loop_thread = new std::thread([=]() {
        do
        {
            char local_data[1024] = "client";
            char remote_data[1024] = {0};
            int recv = 0;
            recv = pre_connector->sock_sync_data(local_data, remote_data, 6);
            LOG(INFO) << "Recved data :" << recv << ", " << remote_data;
            std::this_thread::sleep_for(std::chrono::seconds(1));
        } while (true);
    });
}

int main(int argc, char *argv[])
{
    if (argc < 2)
    {

        RDMAServer *r_server = new RDMAServer();
        r_server->register_cb_after_pre_connect(&callback_server);
        r_server->start_service_async();
        r_server->exit_on_error();
        LOG(INFO) << "Cannot be here";
    }

    else
    {
        std::string server_ip = std::string(argv[1]);
        int server_port = atoi(argv[2]);
        RDMAClient *r_client = new RDMAClient();
        r_client->register_cb_after_pre_connect(&callback_client);
        r_client->connect(server_ip, server_port);
        r_client->exit_on_error();
    }

    // PreConnector *pre_connector = new PreConnector(121, "0.0.0.0", 2345);
}