#include "network_service.h"

namespace communication
{
    void NetworkingService::start_service_async()
    {
    }
} // namespace communication