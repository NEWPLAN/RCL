#ifndef __NEWPLAN_RDMA_SERVICES_H__
#define __NEWPLAN_RDMA_SERVICES_H__
#include "config.h"

namespace communication
{
    class NetworkingService
    {
    public:
        NetworkingService() {}
        virtual ~NetworkingService() {}

    public:
        void init_service(int argc, char **argv)
        {
            config.parse_args(argc, argv);
        }
        void start_service_async();

    private:
        Config config;
    };
} // namespace communication
#endif