#include <iostream>
#include <glog/logging.h>

#include "rdma_base.h"
#include "rdma_adapter.h"
#include "config.h"

#include "endnode.h"
#include "rdma_client.h"
#include "rdma_server.h"
#include <vector>
#include <thread>
#include "utils/net_util.h"

/*assigning a server and a client at each physical node*/
int full_mesh_service(Config &conf_)
{
    std::vector<std::thread *> service_threads;
    LOG(INFO) << "In the full mesh service";
    {
        LOG(INFO) << "launching server service";
        Config new_config = conf_;
        new_config.serve_as_client = false;
        new_config.server_name = "";
        std::thread *server = new std::thread([new_config]() {
            RDMAEndNode *npoint = new RDMAServer();
            npoint->setup(new_config);
            npoint->connect_to_peer();
            npoint->run();
            delete npoint;
        });
        service_threads.push_back(server);
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    {
        LOG(INFO) << "launching client service";
        for (auto &each_server : conf_.cluster)
        {
            CHECK(each_server != conf_.local_ip)
                << "Cannot speficy connection with your own";
            Config new_config = conf_;
            new_config.set_server_name(each_server);
            std::thread *client = new std::thread([new_config]() {
                RDMAEndNode *npoint = new RDMAClient();
                npoint->setup(new_config);
                npoint->connect_to_peer();
                npoint->run();
                delete npoint;
            });
            service_threads.push_back(client);
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
    }

    for (auto &each_thread : service_threads)
        each_thread->join();

    return 0;
}

/*single server(receiver) and multiple clients (senders) */
int server_client_service(Config &conf)
{
    LOG(INFO) << "In the full mesh service";
    RDMAEndNode *npoint = nullptr;
    if (conf.serve_as_client)
    {
        LOG(INFO) << "You are in client side";
        npoint = new RDMAClient();
    }
    else
    {
        LOG(INFO) << "You are in server side";
        npoint = new RDMAServer();
    }

    npoint->setup(conf);
    npoint->connect_to_peer();
    npoint->run();

    delete npoint;
    return 0;
}

static std::string get_neighboring_node(const std::string &this_ip,
                                        const std::vector<std::string> &cluster)
{
    std::string next_hop;
    for (auto &each_node : cluster)
    {
        if (this_ip < each_node)
        {
            next_hop = each_node;
            break;
        }
    }
    if (next_hop.length() == 0 && cluster.size() != 0)
        next_hop = cluster[0]; // the tail is connected to the head node;
    else if (cluster.size() == 0)
        LOG(FATAL) << "[Error] failed to get the next hop";

    return next_hop;
}

/*the ring topology*/
int ring_service(Config &conf)
{
    std::string next_hop = get_neighboring_node(conf.local_ip,
                                                conf.cluster);
    LOG(INFO) << "Next hop: " << conf.local_ip << "-->" << next_hop;
    conf.num_senders = 1;

    std::vector<std::thread *> service_threads;
    LOG(INFO) << "In the ring service";
    {
        LOG(INFO) << "launching server service";
        Config new_config = conf;
        new_config.serve_as_client = false;
        new_config.server_name = "";
        std::thread *server = new std::thread([new_config]() {
            RDMAEndNode *npoint = new RDMAServer();
            npoint->setup(new_config);
            npoint->connect_to_peer();
            npoint->run();
            delete npoint;
        });
        service_threads.push_back(server);
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }

    {
        LOG(INFO) << "launching client service";

        CHECK(next_hop != conf.local_ip)
            << "Cannot speficy connection with your own";
        Config new_config = conf;
        new_config.set_server_name(next_hop);
        std::thread *client = new std::thread([new_config]() {
            RDMAEndNode *npoint = new RDMAClient();
            npoint->setup(new_config);
            npoint->connect_to_peer();
            npoint->run();
            delete npoint;
        });
        service_threads.push_back(client);
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }

    for (auto &each_thread : service_threads)
        each_thread->join();

    return 0;
}

/*the tree topology*/
int tree_service(Config &conf)
{
    LOG(INFO) << "In the tree service" << conf.local_ip;
    return 0;
}

/*the double binary tree topology*/
int double_binary_tree_service(Config &conf)
{
    LOG(INFO) << "In the double binary tree service" << conf.local_ip;
    return 0;
}

int main(int argc, char *argv[])
{
    Config config = Config();
    config.parse_args(argc, argv);
    config.print_config();

    {
        switch (config.all_reduce)
        {
        case SERVER_CLIENT:
            return server_client_service(config);
            break;
        case FULL_MESH_ALLREDUCE:
            return full_mesh_service(config);
            break;
        case RING_ALLREDUCE:
            return ring_service(config);
            break;
        case DOUBLE_BINARY_TREE_ALLREDUCE:
            return double_binary_tree_service(config);
            break;
        case TREE_ALLREDUCE:
            return tree_service(config);
            break;
        case UNKNOWN_ALLREDUCE:
            break;
        }
        LOG(FATAL) << "Unknown service type: "
                   << config.service_type;
    }
    return 0;
}
