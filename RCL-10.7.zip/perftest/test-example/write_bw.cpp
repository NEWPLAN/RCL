/*
 * Copyright (c) 2005 Topspin Communications.  All rights reserved.
 * Copyright (c) 2005 Mellanox Technologies Ltd.  All rights reserved.
 * Copyright (c) 2009 HNR Consulting.  All rights reserved.
 *
 * This software is available to you under a choice of one of two
 * licenses.  You may choose to be licensed under the terms of the GNU
 * General Public License (GPL) Version 2, available from the file
 * COPYING in the main directory of this source tree, or the
 * OpenIB.org BSD license below:
 *
 *     Redistribution and use in source and binary forms, with or
 *     without modification, are permitted provided that the following
 *     conditions are met:
 *
 *      - Redistributions of source code must retain the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer.
 *
 *      - Redistributions in binary form must reproduce the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer in the documentation and/or other materials
 *        provided with the distribution.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 * $Id$
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "config.h"

#include "perftest_parameters.h"
#include "perftest_resources.h"
#include "perftest_communication.h"

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <glog/logging.h>

/******************************************************************************
 ******************************************************************************/
int ib_write_bw_main(int argc, char *argv[])
{
	for (int index = 0; index < argc; index++)
	{
		printf("%s ", argv[index]);
	}
	printf("\n");
	int ret_parser, i = 0, rc;
	struct ibv_device *ib_dev = NULL;
	struct pingpong_context ctx;
	struct pingpong_dest *my_dest, *rem_dest;
	struct perftest_parameters user_param;
	struct perftest_comm user_comm;
	struct bw_report_data my_bw_rep, rem_bw_rep;

	/* init default values to user's parameters */
	memset(&user_param, 0, sizeof(struct perftest_parameters));
	memset(&user_comm, 0, sizeof(struct perftest_comm));
	memset(&ctx, 0, sizeof(struct pingpong_context));

	user_param.verb = WRITE;
	user_param.tst = BW;
	strncpy(user_param.version, VERSION, sizeof(user_param.version));

	/* Configure the parameters values according to user arguments or default values. */
	ret_parser = parser(&user_param, argv, argc);
	if (ret_parser)
	{
		if (ret_parser != VERSION_EXIT && ret_parser != HELP_EXIT)
			fprintf(stderr, " Parser function exited with Error\n");
		return FAILURE;
	}

	if ((user_param.connection_type == DC || user_param.use_xrc) && user_param.duplex)
	{
		user_param.num_of_qps *= 2;
	}

	/* Finding the IB device selected (or default if none is selected). */
	ib_dev = ctx_find_dev(&user_param.ib_devname);
	if (!ib_dev)
	{
		fprintf(stderr, " Unable to find the Infiniband/RoCE device\n");
		return FAILURE;
	}

	/* Getting the relevant context from the device */
	ctx.context = ibv_open_device(ib_dev);
	if (!ctx.context)
	{
		fprintf(stderr, " Couldn't get context for the device\n");
		return FAILURE;
	}

	/* Verify user parameters that require the device context,
	 * the function will print the relevent error info. */
	if (verify_params_with_device_context(ctx.context, &user_param))
	{
		fprintf(stderr, " Couldn't get context for the device\n");
		return FAILURE;
	}

	/* See if MTU and link type are valid and supported. */
	if (check_link(ctx.context, &user_param))
	{
		fprintf(stderr, " Couldn't get context for the device\n");
		return FAILURE;
	}

	/* copy the relevant user parameters to the comm struct + creating rdma_cm resources. */
	if (create_comm_struct(&user_comm, &user_param))
	{
		fprintf(stderr, " Unable to create RDMA_CM resources\n");
		return FAILURE;
	}

	if (user_param.output == FULL_VERBOSITY && user_param.machine == SERVER)
	{
		printf("\n************************************\n");
		printf("* Waiting for client to connect... *\n");
		printf("************************************\n");
	}

	/* Initialize the connection and print the local data. */
	if (establish_connection(&user_comm))
	{
		fprintf(stderr, " Unable to init the socket connection\n");
		return FAILURE;
	}
	sleep(1);

	exchange_versions(&user_comm, &user_param);
	check_version_compatibility(&user_param);
	check_sys_data(&user_comm, &user_param);

	/* See if MTU and link type are valid and supported. */
	if (check_mtu(ctx.context, &user_param, &user_comm))
	{
		fprintf(stderr, " Couldn't get context for the device\n");
		return FAILURE;
	}

	ALLOCATE(my_dest, struct pingpong_dest, user_param.num_of_qps);
	memset(my_dest, 0, sizeof(struct pingpong_dest) * user_param.num_of_qps);
	ALLOCATE(rem_dest, struct pingpong_dest, user_param.num_of_qps);
	memset(rem_dest, 0, sizeof(struct pingpong_dest) * user_param.num_of_qps);

	/* Allocating arrays needed for the test. */
	alloc_ctx(&ctx, &user_param);

	/* Create RDMA CM resources and connect through CM. */
	if (user_param.work_rdma_cm == ON)
	{
		rc = create_rdma_cm_connection(&ctx, &user_param, &user_comm,
									   my_dest, rem_dest);
		if (rc)
		{
			fprintf(stderr,
					"Failed to create RDMA CM connection with resources.\n");
			return FAILURE;
		}
	}
	else
	{
		/* create all the basic IB resources (data buffer, PD, MR, CQ and events channel) */
		if (ctx_init(&ctx, &user_param))
		{
			fprintf(stderr, " Couldn't create IB resources\n");
			return FAILURE;
		}
	}

	/* Set up the Connection. */
	if (set_up_connection(&ctx, &user_param, my_dest))
	{
		fprintf(stderr, " Unable to set up socket connection\n");
		return FAILURE;
	}

	/* Print basic test information. */
	ctx_print_test_info(&user_param);

	for (i = 0; i < user_param.num_of_qps; i++)
	{

		if (ctx_hand_shake(&user_comm, &my_dest[i], &rem_dest[i]))
		{
			fprintf(stderr, " Failed to exchange data between server and clients\n");
			return FAILURE;
		}
	}

	if (user_param.work_rdma_cm == OFF)
	{
		if (ctx_check_gid_compatibility(&my_dest[0], &rem_dest[0]))
		{
			fprintf(stderr, "\n Found Incompatibility issue with GID types.\n");
			fprintf(stderr, " Please Try to use a different IP version.\n\n");
			return FAILURE;
		}
	}

	if (user_param.work_rdma_cm == OFF)
	{
		if (ctx_connect(&ctx, rem_dest, &user_param, my_dest))
		{
			fprintf(stderr, " Unable to Connect the HCA's through the link\n");
			return FAILURE;
		}
	}

	if (user_param.connection_type == DC)
	{
		/* Set up connection one more time to send qpn properly for DC */
		if (set_up_connection(&ctx, &user_param, my_dest))
		{
			fprintf(stderr, " Unable to set up socket connection\n");
			return FAILURE;
		}
	}

	/* Print this machine QP information */
	for (i = 0; i < user_param.num_of_qps; i++)
		ctx_print_pingpong_data(&my_dest[i], &user_comm);

	user_comm.rdma_params->side = REMOTE;

	for (i = 0; i < user_param.num_of_qps; i++)
	{

		if (ctx_hand_shake(&user_comm, &my_dest[i], &rem_dest[i]))
		{
			fprintf(stderr, " Failed to exchange data between server and clients\n");
			return FAILURE;
		}

		ctx_print_pingpong_data(&rem_dest[i], &user_comm);
	}

	/* An additional handshake is required after moving qp to RTR. */
	if (ctx_hand_shake(&user_comm, &my_dest[0], &rem_dest[0]))
	{
		fprintf(stderr, " Failed to exchange data between server and clients\n");
		return FAILURE;
	}

	if (user_param.output == FULL_VERBOSITY)
	{
		if (user_param.report_per_port)
		{
			printf(RESULT_LINE_PER_PORT);
			printf((user_param.report_fmt == MBS ? RESULT_FMT_PER_PORT : RESULT_FMT_G_PER_PORT));
		}
		else
		{
			printf(RESULT_LINE);
			printf((user_param.report_fmt == MBS ? RESULT_FMT : RESULT_FMT_G));
		}

		printf((user_param.cpu_util_data.enable ? RESULT_EXT_CPU_UTIL : RESULT_EXT));
	}

	/* For half duplex tests, server just waits for client to exit */
	if (user_param.machine == SERVER && !user_param.duplex)
	{

		if (ctx_hand_shake(&user_comm, &my_dest[0], &rem_dest[0]))
		{
			fprintf(stderr, " Failed to exchange data between server and clients\n");
			return FAILURE;
		}

		xchg_bw_reports(&user_comm, &my_bw_rep, &rem_bw_rep, atof(user_param.rem_version));
		print_full_bw_report(&user_param, &rem_bw_rep, NULL);

		if (ctx_close_connection(&user_comm, &my_dest[0], &rem_dest[0]))
		{
			fprintf(stderr, "Failed to close connection between server and client\n");
			return FAILURE;
		}

		if (user_param.output == FULL_VERBOSITY)
		{
			if (user_param.report_per_port)
				printf(RESULT_LINE_PER_PORT);
			else
				printf(RESULT_LINE);
		}

		if (user_param.work_rdma_cm == ON)
		{
			if (destroy_ctx(&ctx, &user_param))
			{
				fprintf(stderr, "Failed to destroy resources\n");
				return FAILURE;
			}

			user_comm.rdma_params->work_rdma_cm = OFF;
			return destroy_ctx(user_comm.rdma_ctx, user_comm.rdma_params);
		}

		return destroy_ctx(&ctx, &user_param);
	}

	if (user_param.test_method == RUN_ALL)
	{

		for (i = 1; i < 24; ++i)
		{

			user_param.size = (uint64_t)1 << i;
			ctx_set_send_wqes(&ctx, &user_param, rem_dest);

			if (user_param.perform_warm_up)
			{
				if (perform_warm_up(&ctx, &user_param))
				{
					fprintf(stderr, "Problems with warm up\n");
					return FAILURE;
				}
			}

			if (user_param.duplex)
			{
				if (ctx_hand_shake(&user_comm, &my_dest[0], &rem_dest[0]))
				{
					fprintf(stderr, "Failed to sync between server and client between different msg sizes\n");
					return FAILURE;
				}
			}

			if (run_iter_bw(&ctx, &user_param))
			{
				fprintf(stderr, " Failed to complete run_iter_bw function successfully\n");
				return FAILURE;
			}

			if (user_param.duplex && (atof(user_param.version) >= 4.6))
			{
				if (ctx_hand_shake(&user_comm, &my_dest[0], &rem_dest[0]))
				{
					fprintf(stderr, "Failed to sync between server and client between different msg sizes\n");
					return FAILURE;
				}
			}

			print_report_bw(&user_param, &my_bw_rep);

			if (user_param.duplex)
			{
				xchg_bw_reports(&user_comm, &my_bw_rep, &rem_bw_rep, atof(user_param.rem_version));
				print_full_bw_report(&user_param, &my_bw_rep, &rem_bw_rep);
			}
		}
	}
	else if (user_param.test_method == RUN_REGULAR)
	{

		ctx_set_send_wqes(&ctx, &user_param, rem_dest);

		if (user_param.verb != SEND)
		{

			if (user_param.perform_warm_up)
			{
				if (perform_warm_up(&ctx, &user_param))
				{
					fprintf(stderr, "Problems with warm up\n");
					return FAILURE;
				}
			}
		}

		if (user_param.duplex)
		{
			if (ctx_hand_shake(&user_comm, &my_dest[0], &rem_dest[0]))
			{
				fprintf(stderr, "Failed to sync between server and client between different msg sizes\n");
				return FAILURE;
			}
		}

		if (run_iter_bw(&ctx, &user_param))
		{
			fprintf(stderr, " Failed to complete run_iter_bw function successfully\n");
			return FAILURE;
		}

		print_report_bw(&user_param, &my_bw_rep);

		if (user_param.duplex)
		{
			xchg_bw_reports(&user_comm, &my_bw_rep, &rem_bw_rep, atof(user_param.rem_version));
			print_full_bw_report(&user_param, &my_bw_rep, &rem_bw_rep);
		}

		if (user_param.report_both && user_param.duplex)
		{
			printf(RESULT_LINE);
			printf("\n Local results: \n");
			printf(RESULT_LINE);
			printf((user_param.report_fmt == MBS ? RESULT_FMT : RESULT_FMT_G));
			printf((user_param.cpu_util_data.enable ? RESULT_EXT_CPU_UTIL : RESULT_EXT));
			print_full_bw_report(&user_param, &my_bw_rep, NULL);
			printf(RESULT_LINE);

			printf("\n Remote results: \n");
			printf(RESULT_LINE);
			printf((user_param.report_fmt == MBS ? RESULT_FMT : RESULT_FMT_G));
			printf((user_param.cpu_util_data.enable ? RESULT_EXT_CPU_UTIL : RESULT_EXT));
			print_full_bw_report(&user_param, &rem_bw_rep, NULL);
		}
	}
	else if (user_param.test_method == RUN_INFINITELY)
	{

		ctx_set_send_wqes(&ctx, &user_param, rem_dest);

		if (run_iter_bw_infinitely(&ctx, &user_param))
		{
			fprintf(stderr, " Error occurred while running infinitely! aborting ...\n");
			return FAILURE;
		}
	}

	if (user_param.output == FULL_VERBOSITY)
	{
		if (user_param.report_per_port)
			printf(RESULT_LINE_PER_PORT);
		else
			printf(RESULT_LINE);
	}

	/* For half duplex tests, server just waits for client to exit */
	if (user_param.machine == CLIENT && !user_param.duplex)
	{

		if (ctx_hand_shake(&user_comm, &my_dest[0], &rem_dest[0]))
		{
			fprintf(stderr, " Failed to exchange data between server and clients\n");
			return FAILURE;
		}

		xchg_bw_reports(&user_comm, &my_bw_rep, &rem_bw_rep, atof(user_param.rem_version));
	}

	/* Closing connection. */
	if (ctx_close_connection(&user_comm, &my_dest[0], &rem_dest[0]))
	{
		fprintf(stderr, "Failed to close connection between server and client\n");
		return FAILURE;
	}

	if (!user_param.is_bw_limit_passed && (user_param.is_limit_bw == ON))
	{
		fprintf(stderr, "Error: BW result is below bw limit\n");
		return FAILURE;
	}

	if (!user_param.is_msgrate_limit_passed && (user_param.is_limit_bw == ON))
	{
		fprintf(stderr, "Error: Msg rate  is below msg_rate limit\n");
		return FAILURE;
	}

	free(my_dest);
	free(rem_dest);

	if (user_param.work_rdma_cm == ON)
	{
		if (destroy_ctx(&ctx, &user_param))
		{
			fprintf(stderr, "Failed to destroy resources\n");
			return FAILURE;
		}

		user_comm.rdma_params->work_rdma_cm = OFF;
		return destroy_ctx(user_comm.rdma_ctx, user_comm.rdma_params);
	}

	return destroy_ctx(&ctx, &user_param);
}

#ifndef __NETTOOLS_H__
#define __NETTOOLS_H__

#include <stdio.h>
#include <sys/types.h>
#include <ifaddrs.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
#include <string>

class NetTool
{
public:
	NetTool() {}
	virtual ~NetTool() {}
	static std::string get_ip(const char *ip_prefix, int ip_prefix_length)
	{
		char ip_[60] = {0};
		uint32_t ip = (uint32_t)inet_addr(ip_prefix);
		uint32_t len = ip_prefix_length;
		uint32_t ip_local = (ip << (32 - len)) >> (32 - len);
		uint32_t gtway = ip_local + (1 << ip_prefix_length);
		struct in_addr ip_gateway;
		memcpy(&ip_gateway, &gtway, sizeof(uint32_t));

		sprintf(ip_, "%s", inet_ntoa(ip_gateway));
		ip_[strlen(ip_) - 1] = 0;
		int node_id = get_node_id(ip_prefix, ip_prefix_length);

		std::string this_ip = std::string(ip_prefix, strlen(ip_) - 1);
		this_ip += std::string(".") + std::to_string(node_id);
		//printf("this_ip: %s\n", this_ip.c_str());
		return this_ip;
	}
	static int get_node_id(const char *ip_prefix, int ip_prefix_length)
	{

		char ip_[60] = {0};
		uint32_t ip = (uint32_t)inet_addr(ip_prefix);
		uint32_t len = ip_prefix_length;
		uint32_t ip_local = (ip << (32 - len)) >> (32 - len);
		uint32_t gtway = ip_local + (1 << ip_prefix_length);
		struct in_addr ip_gateway;
		memcpy(&ip_gateway, &gtway, sizeof(uint32_t));

		sprintf(ip_, "%s", inet_ntoa(ip_gateway));
		ip_[strlen(ip_) - 1] = 0;
		ip_prefix_length = strlen(ip_);

		struct ifaddrs *ifAddrStruct = NULL;
		struct ifaddrs *ifa = NULL;
		void *tmpAddrPtr = NULL;

		int node_id = -1;

		getifaddrs(&ifAddrStruct);

		for (ifa = ifAddrStruct; ifa != NULL; ifa = ifa->ifa_next)
		{
			if (!ifa->ifa_addr)
			{
				continue;
			}
			if (ifa->ifa_addr->sa_family == AF_INET) // check it is IP4
			{
				// is a valid IP4 Address
				tmpAddrPtr = &((struct sockaddr_in *)ifa->ifa_addr)->sin_addr;
				char addressBuffer[INET_ADDRSTRLEN];
				inet_ntop(AF_INET, tmpAddrPtr, addressBuffer, INET_ADDRSTRLEN);
				if (strncmp(addressBuffer, ip_prefix, ip_prefix_length) == 0)
				{
					node_id = atoi(addressBuffer + ip_prefix_length);
#ifdef DEBUG_SHOW_IP
					printf("%s IP Address %s\n", ifa->ifa_name, addressBuffer);
#endif
				}
			}
			else if (ifa->ifa_addr->sa_family == AF_INET6) // check it is IP6
			{
				continue;
				// is a valid IP6 Address
				tmpAddrPtr = &((struct sockaddr_in6 *)ifa->ifa_addr)->sin6_addr;
				char addressBuffer[INET6_ADDRSTRLEN];
				inet_ntop(AF_INET6, tmpAddrPtr, addressBuffer, INET6_ADDRSTRLEN);
#ifdef DEBUG_SHOW_IP
				printf("%s IP Address %s\n", ifa->ifa_name, addressBuffer);
#endif
			}
		}
		if (ifAddrStruct != NULL)
		{
			freeifaddrs(ifAddrStruct);
		}

		return node_id;
	}
};

#endif

char *bytes_specify = (char *)"-s";
char *total_bytes = (char *)"8192";

#include <thread>
#include <chrono>
#include <atomic>
#include <string>
#include <vector>
#include <iostream>

void server_function(std::vector<std::string> ip_table, char *const argv[], int argc)
{
	printf("args numer: %d\n", argc);

	for (auto &each : ip_table)
	{
		char ip_index[20] = {0};

		sprintf(ip_index, "%s", each.c_str());
		int ip_addr = atoi(ip_index + 9);
		LOG(INFO) << "Remote IP addr: " << ip_addr;

		char **tmp_client_base = new char *[argc + 2];
		for (int index = 0; index < argc; index++)
		{
			tmp_client_base[index] = new char[strlen(argv[index]) + 1];
			memcpy(tmp_client_base[index], argv[index], strlen(argv[index]));
			tmp_client_base[index][strlen(argv[index])] = 0;
			//printf("%s ", tmp_client_base[index]);
		}
		//printf("\n");
		memset(tmp_client_base[argc - 1], 0, strlen(tmp_client_base[argc - 1]));
		sprintf(tmp_client_base[argc - 1], "12%d", ip_addr);
		{ //load msg_size
			tmp_client_base[argc] = new char[strlen(bytes_specify) + 1];
			memset(tmp_client_base[argc], 0, strlen(bytes_specify) + 1);
			memcpy(tmp_client_base[argc], bytes_specify, strlen(bytes_specify));

			tmp_client_base[argc + 1] = new char[strlen(total_bytes) + 1];
			memset(tmp_client_base[argc + 1], 0, strlen(total_bytes) + 1);
			memcpy(tmp_client_base[argc + 1], total_bytes, strlen(total_bytes));
		}
		int pid = fork();
		if (pid == 0)
		{
			char **seconds_client_base = tmp_client_base;
			ib_write_bw_main(argc + 2, seconds_client_base);
		}
		std::this_thread::sleep_for(std::chrono::seconds(1));
	}

	do
	{

		std::this_thread::sleep_for(std::chrono::seconds(1));
	} while (1);
}
void client_function(std::vector<std::string> ip_addr, char *const argv[], int argc)
{

	std::vector<std::thread *> client_threads;

	std::string local_ip = NetTool::get_ip("12.12.12.1", 24);
	char ip_index[20] = {0};

	sprintf(ip_index, "%s", local_ip.c_str());
	int local_ip_index = atoi(ip_index + 9);

	for (auto &peer : ip_addr)
	{
		char **tmp_client_base = new char *[argc + 2];
		for (int index = 0; index < argc; index++)
		{
			tmp_client_base[index] = new char[strlen(argv[index]) + 1];
			memcpy(tmp_client_base[index], argv[index], strlen(argv[index]));
			tmp_client_base[index][strlen(argv[index])] = 0;
			//printf("%s ", tmp_client_base[index]);
		}
		//printf("\n");
		memcpy(tmp_client_base[argc - 1], peer.c_str(), strlen(tmp_client_base[argc - 1]));
		sprintf(tmp_client_base[argc - 3], "12%d", local_ip_index, strlen(tmp_client_base[argc - 3]));

		{ //load msg_size
			tmp_client_base[argc] = new char[strlen(bytes_specify) + 1];
			memset(tmp_client_base[argc], 0, strlen(bytes_specify) + 1);
			memcpy(tmp_client_base[argc], bytes_specify, strlen(bytes_specify));

			tmp_client_base[argc + 1] = new char[strlen(total_bytes) + 1];
			memset(tmp_client_base[argc + 1], 0, strlen(total_bytes) + 1);
			memcpy(tmp_client_base[argc + 1], total_bytes, strlen(total_bytes));
		}
		int pid = fork();
		if (pid == 0)
		{
			char **seconds_client_base = tmp_client_base;
			ib_write_bw_main(argc + 2, seconds_client_base);
		}

		// client_threads.push_back(new std::thread([argc, tmp_client_base] {
		// 	char** seconds_client_base=tmp_client_base;
		// 	ib_write_bw_main(argc, seconds_client_base); }));
		std::this_thread::sleep_for(std::chrono::seconds(1));
	}
	do
	{
		//std::cout << "client is launched, connect to: " << argv[argc - 1] << std::endl;
		std::this_thread::sleep_for(std::chrono::seconds(1));
	} while (1);
}

int main(int argc, char *argv[])
{
	// ib_write_bw_main(argc, argv);
	// return 0;
	char *server_args[] = {(char *)"./rdma_write_benchmark",
						   (char *)"-a",
						   (char *)"-d",
						   (char *)"mlx5_0",
						   (char *)"--run_infinitely",
						   (char *)"--tclass=0",
						   (char *)"-x",
						   (char *)"3",
						   (char *)"-p",
						   (char *)"12101"};
	char *client_args[] = {(char *)"./rdma_write_benchmark",
						   (char *)"-a",
						   (char *)"-d",
						   (char *)"mlx5_0",
						   (char *)"--report_gbits",
						   (char *)"--run_infinitely",
						   (char *)"--tclass=0",
						   (char *)"-x",
						   (char *)"3",
						   (char *)"-p",
						   (char *)"12101",
						   (char *)"-F",
						   (char *)"12.12.12.111"};

	std::string local_ip = NetTool::get_ip("12.12.12.1", 24);
	printf("local IP: %s\n", local_ip.c_str());

	if (argc < 2)
	{
		printf("%s --server/client, to run the server/client side\n", argv[0]);
		printf("%s --cluster ip1 ip2 ... ipn, to run the cluster side\n", argv[0]);
		exit(0);
	}
	else if (strcmp(argv[1], "--server") == 0)
	{
		ib_write_bw_main(sizeof(server_args) / sizeof(char *), server_args);
	}
	else if (strcmp(argv[1], "--client") == 0)
	{
		ib_write_bw_main(sizeof(client_args) / sizeof(char *), client_args);
	}
	else if (strcmp(argv[1], "--cluster") == 0)
	{
		std::vector<std::string> ip_address;
		for (int index = 1; index < argc; index++)
		{
			if (strncmp(argv[index], "12.12.12.", 9) != 0)
				continue;
			std::string ip = std::string(argv[index]);
			if (ip == local_ip)
				continue;
			std::cout << "IP: " << ip << std::endl;
			ip_address.push_back(ip);
		}

		std::thread *server_thread; //
		std::thread *client_thread;
		server_thread = new std::thread([ip_address, server_args]() {
			server_function(ip_address, server_args, sizeof(server_args) / sizeof(char *));
			while (1)
				sleep(1);
		});
		client_thread = new std::thread([ip_address, client_args]() {
			client_function(ip_address, client_args, sizeof(client_args) / sizeof(char *));
		});
		server_thread->join();
		client_thread->join();
	}
	else
	{
		std::cout << "unknown arguments" << std::endl;
	}
	std::atomic_bool iCount(true);

	return 0;
}