#ifndef __RDMA_MEM_MGR_H__
#define __RDMA_MEM_MGR_H__
class RDMAMemMgr
{
public:
    RDMAMemMgr() {}
    virtual ~RDMAMemMgr() {}
};
#endif